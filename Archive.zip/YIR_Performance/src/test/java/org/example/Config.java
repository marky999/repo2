package org.example;

public class Config {
    //public static final String JSON_FILE_PATH = "cnf_free.json";
    public static final String JSON_FILE_PATH = "cnf_prime.json";
}
